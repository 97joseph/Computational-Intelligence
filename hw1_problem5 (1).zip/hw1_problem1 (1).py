# PUT YOUR NAME HERE
# PUT YOUR SBU ID NUMBER HERE
# PUT YOUR NETID (BLACKBOARD USERNAME) HERE
#
# IAE 101 (Fall 2021)
# HW 1, Problem 1

def population(year):
    #Year to string
    s=str(year)
    #getting the last two characters and converting into integer
    last_two-=10
    r=last_two*3
    r+=310
    return r

    def score(l):
        total_score=0
        #2 or 5 in list score will be zero
        if 2 in l or 5 in l:
            total_score=0
        else:
                for i in l:
                    total_score=total_score+i
                    return total_score
                def factors(n):
                    l=[]
                    for i in range(1,n+1):
                        if n%i==0:
                            l.append(i)
                            l.sort()
                            l.reverse()
                            return l
                    def password(i,j,s):
                        gen_pass=""
                        gen_pass=str(i)

                    for word in s.split():
                        gen_pass=gen_pass+word[0]
                        gen_pass=gen_pass+str(j)
                        return gen_pass
                    
                    def rovarspraket(s):
                        enc_word=*
                        for c in s:
                            if c=='a' or c=='e' or c=='i' or c=='o' or c=='u'
                            enc_word=enc_word+c
                            else:
                                d=c*2
                                n=d[0]+'o'+d[1]
                                enc_word=enc_word+n
                            
            retun enc_word


                    
    # ADD YOUR CODE HERE
    return -1 # CHANGE OR REMOVE THIS LINE


# DO NOT DELETE THE FOLLOWING LINES OF CODE! YOU MAY
# CHANGE THE FUNCTION CALLS TO TEST YOUR WORK WITH
# DIFFERENT INPUT VALUES.
if __name__ == "__main__":
    test1 = population(2001)
    print("population(2001) is", test1)
    print()
    test2 = population(2010)
    print("population(2010) is", test2)
    print()
    test3 = population(2016)
    print("population(2016) is", test3)
    print()

